<!DOCTYPE html>
<html>
    <head>
	    <title>Ariicha Agency | Accesso</title>
	    <link rel="stylesheet" type="text/css" href="../css/styles.css">
    </head>
    <body>
        <header>
            <img src="../immagini/logo.jpg" alt="" width="250px">
            <nav class="navbar">
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="index.php#destinazioni">Destinazioni</a></li>
                </ul>
            </nav>
        </header>

        <div class="accedi">
            <form action="contr-accedi.php" method="post">
     	        <h2>ACCEDI</h2>
                <?php if (isset($_GET['error'])) { ?>
     		    <p class="error"><?php echo $_GET['error']; ?></p>
     	        <?php } ?>
     	        <label>Nome Utente</label>
     	        <input type="text" name="nome_ut" placeholder="Nome Utente"><br>

     	        <label>Password</label>
     	        <input type="password" name="password" placeholder="Password"><br>

     	        <button type="submit">Accedi</button>
                <a href="registrazione.php" class="ca">Crea un account</a>
            </form>
        </div>
    </body>
</html>
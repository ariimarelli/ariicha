<?php
session_start();
if (isset($_SESSION['id']) && isset($_SESSION['nome_utente'])) {
?>

<!DOCTYPE html>
<html>
    <head>
	    <title>Ariicha Agency | Prenota</title>
	    <link rel="stylesheet" type="text/css" href="../css/styles.css">
    </head>

    <body>
        <header>
            <img src="../immagini/logo.jpg" alt="" width="250px">
            <nav class="navbar">
                <ul>
                    <li><a href="index.php">Home</a></li>
                </ul>
            </nav>
        </header>

        <div class="elenco">
            <br></br>
            <h1>Bene, <?php echo $_SESSION['nome']; ?></h1>
            <h1>la tua prenotazione</h1>
            <h1> e' stata confermata </h1>
        
            <form>
                <button type="submit"><a href="../html/svezia.html">Clicca per saperne di più</a></button>
            </form>
        </div>
    </body>
</html>

<?php 
}else{
     header("Location: accedi.php");
     exit();
}
?>
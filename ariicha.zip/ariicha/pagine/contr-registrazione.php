<?php 
session_start(); 
include "../database/db_conn.php";

if (isset($_POST['nome_ut']) && isset($_POST['password'])
    && isset($_POST['nome']) && isset($_POST['re_password'])) {

	function validate($data){
       $data = trim($data);
	   $data = stripslashes($data);
	   $data = htmlspecialchars($data);
	   return $data;
	}

	$nome_ut = validate($_POST['nome_ut']);
	$pass = validate($_POST['password']);

	$re_pass = validate($_POST['re_password']);
	$nome = validate($_POST['nome']);

	$utente_data = 'nome_ut='. $nome_ut. '&nome='. $nome;


	if (empty($nome_ut)) {
		header("Location: registrazione.php?error=È necessario inserire il Nome Utente&$utente_data");
	    exit();
	}else if(empty($pass)){
        header("Location: registrazione.php?error=È necessario inserire la Password&$utente_data");
	    exit();
	}
	else if(empty($re_pass)){
        header("Location: registrazione.php?error=È necessario reinserire la Password&$utente_data");
	    exit();
	}

	else if(empty($nome)){
        header("Location: registrazione.php?error=È necessario inserire il Nome&$utente_data");
	    exit();
	}

	else if($pass !== $re_pass){
        header("Location: registrazione.php?error=La Password di conferma non corrisponde&$utente_data");
	    exit();
	}

	else{
       

	    $sql = "SELECT * FROM utenti WHERE nome_utente='$nome_ut' ";
		$result = mysqli_query($conn, $sql);

		if (mysqli_num_rows($result) > 0) {
			header("Location: registrazione.php?error=Il Nome Utente è già in uso, provane un altro&$utente_data");
	        exit();
		}else {
           $sql2 = "INSERT INTO utenti(nome_utente, password, nome) VALUES('$nome_ut', '$pass', '$nome')";
           $result2 = mysqli_query($conn, $sql2);
           if ($result2) {
           	 header("Location: registrazione.php?success=Il tuo account è stato creato con successo, ora esegui l'accesso per prenotare");
	         exit();
           }else {
	           	header("Location: registrazione.php?error=errore sconosciuto&$utente_data");
		        exit();
           }
		}
	}
	
}else{
	header("Location: registrazione.php");
	exit();
}
<?php 
session_start(); 
include "../database/db_conn.php";

if (isset($_POST['nome_ut']) && isset($_POST['password'])) {

	function validate($data){
       $data = trim($data);
	   $data = stripslashes($data);
	   $data = htmlspecialchars($data);
	   return $data;
	}

	$nome_ut = validate($_POST['nome_ut']);
	$pass = validate($_POST['password']);

	if (empty($nome_ut)) {
		header("Location: accedi.php?error=È necessario inserire il Nome Utente");
	    exit();
	}else if(empty($pass)){
        header("Location: accedi.php?error=È necessario inserire la Password");
	    exit();
	}else{
		
		$sql = "SELECT * FROM utenti WHERE nome_utente='$nome_ut' AND password='$pass'";

		$result = mysqli_query($conn, $sql);

	

		if (mysqli_num_rows($result) === 1) {
			$row = mysqli_fetch_assoc($result);
            if ($row['nome_utente'] === $nome_ut && $row['password'] === $pass) {
            	$_SESSION['nome_utente'] = $row['nome_utente'];
            	$_SESSION['nome'] = $row['nome'];
            	$_SESSION['id'] = $row['id'];
            	header("Location: prenota.php");
		        exit();
            }else{
				header("Location: accedi.php?error=Il Nome Utente o la Passwors sono errati");
		        exit();
			}
		}else{
			header("Location: accedi.php?error=Il Nome Utente o la Password sono errati");
	        exit();
		}
	}
	
}else{
	header("Location: accedi.php");
	exit();
}
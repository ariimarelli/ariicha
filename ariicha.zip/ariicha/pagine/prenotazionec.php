<!DOCTYPE html>
<html>
    <head>
	    <title>PRENOTA</title>
	    <link rel="stylesheet" type="text/css" href="../css/styleprenotazioni.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.css">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
    </head>

    <body>
        <header>
            <img src="../immagini/logo.jpg" alt="" width="250px">
            <nav class="navbar">
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="index.php#destinazioni">Destinazioni</a></li>
                </ul>
            </nav>
        </header>

        <div class="accedi">
            <form action="prenotazionec.php" method="post">
                <h2>PRENOTA</h2>
                <?php if (isset($_POST['error'])) { ?>
     		    <p class="error">
                    <?php echo $_POST['error']; ?>
                </p>
                <?php }
                ?>
                
                <br></br>
                
                <label>numero persone</label>
                <select name="numeropersone" id="numero">
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                    <option value="6">6</option>
                    <option value="7">7</option>
                    <option value="8">8</option>
                    <option value="9">9</option>
                    <option value="10">10</option>
                </select>
                
                <br></br>
                
                <form method="POST">
                    <label for="checkin">Check-in:</label>
                    <input type="text" id="checkin" name="checkin_date" readonly>
                    
                    <br>
        
                    <label for="checkout">Check-out:</label>
                    <input type="text" id="checkout" name="checkout_date" readonly>
        
                    <br>
                    
                    <script>
                    
                    $(function() {
                        $("#checkin").datepicker({
                            minDate: 0,
                            onSelect: function(selected) {
                                $("#checkout").datepicker("option", "minDate", selected)
                            }
                        });
                        
                        $("#checkout").datepicker({
                            minDate: 1 
                        });
                    });
                    
                    </script>
                    
                    <label for="foglio">SCEGLI LA TUA DESTINAZIONE</label>
  
                    <br></br>
    
                    <select name="pagina" id="pagina">

                        <option value="pagina1">Londra,Inghilterra</option>
                        <option value="pagina2">Parigi,Francia</option>
                        <option value="pagina3">Berlino,Germania</option>
                        <option value="pagina4">Roma,Italia</option>
                        <option value="pagina5">Alanya,Turchia</option>
                        <option value="pagina6">Bonifacio,Francia</option>
                        <option value="pagina7">Rodas,Spagna</option>
                        <option value="pagina8">Reynisfjara,Islanda</option>
                        <option value="pagina9">Dolomiti,Italia</option>
                        <option value="pagina10">Alti Tauri,Austria</option>
                        <option value="pagina11">Pirenei,Spagna</option>
                        <option value="pagina12">Stortoppen,Svezia</option>
                    
                    </select>
                    <input type="submit" value="Prenota!">
                </form>
            </form>
        </div>
        
        <?php
        if(isset($_REQUEST['pagina'])) {
            $pagina = $_REQUEST['pagina'];
            switch($pagina) {
        
            case 'pagina1':
                header('Location: 1.php');
                exit();
                
            case 'pagina2':
                header('Location:2.php');
                exit();

            case 'pagina3':
                header('Location: 3.php');
                exit();
                
            case 'pagina4':
                header('Location: 4.php');
                exit();   
                        
            case 'pagina5':
                header('Location: 5.php');
                exit();
                        
            case 'pagina6':
                header('Location: 6.php');
                exit();
                        
            case 'pagina7':
                header('Location: 7.php');
                exit();

            case 'pagina8':
                header('Location: 8.php');
                exit();     
                                
            case 'pagina9':
                header('Location:9.php');
                exit();
                                
            case 'pagina10':
                header('Location: 10.php');
                exit();
                                
            case 'pagina11':
                header('Location: 11.php');
                exit();
                                
            case 'pagina12':
                header('Location: 12.php');
                exit();
            
                default:
                echo "Pagina non valida";
                exit();    
            }
        }
        ?>
    </body>
</html>
















<!DOCTYPE html>
<html>
     <head>
	     <title>Ariicha Agency | Registrazione</title>
	     <link rel="stylesheet" type="text/css" href="../css/styles.css">
     </head>
     <body>
          <header>
               <img src="../immagini/logo.jpg" alt="" width="250px">
               <nav class="navbar">
                    <ul>
                         <li><a href="index.php">Home</a></li>
                         <li><a href="index.php#destinazioni">Destinazioni</a></li>
                    </ul>
               </nav>
          </header>
          
          <div class="accedi">
               <form action="contr-registrazione.php" method="post">
                    <h2>REGISTRATI</h2>
                    <?php if (isset($_GET['error'])) { ?>
                         <p class="error"><?php echo $_GET['error']; ?></p>
                         <?php } ?>
                         
                    <?php if (isset($_GET['success'])) { ?>
                         <p class="success"><?php echo $_GET['success']; ?></p>
                         <?php } ?>
                         
                    <label>Nome</label>
                    <?php if (isset($_GET['nome'])) { ?>
                         <input type="text" name="nome" placeholder="Nome" value="<?php echo $_GET['nome']; ?>"><br>
                         
                    <?php }else{ ?>
                         <input type="text" name="nome" placeholder="Nome"><br>
                    <?php }?>

                    <label>Nome Utente</label>
                    <?php if (isset($_GET['nome_ut'])) { ?>
                         <input type="text" name="nome_ut" placeholder="Nome Utente"value="<?php echo $_GET['nome_ut']; ?>"><br>
                    <?php }else{ ?>
                         <input type="text" name="nome_ut" placeholder="Nome Utente"><br>
                    <?php }?>


     	          <label>Password</label>
     	               <input type="password" name="password" placeholder="Password"><br>

                    <label>Reinserisci Password</label>
                         <input type="password" name="re_password" placeholder="Reinserisci Password"><br>
                         
                         <button type="submit">Registrati</button>
                         <a href="accedi.php" class="ca">Hai già un account?</a>
               </form>
          </div>
     </body>
</html>
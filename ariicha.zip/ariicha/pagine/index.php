<!DOCTYPE html>
<html lang="it">
    <head>
        <title>Ariicha Agency | Home</title>
        <link rel="stylesheet" href="../css/style.css">
    </head>
    <body>
        <header>
            <img src="../immagini/logo.jpg" alt="" width="250px">
            <nav class="navbar">
                <ul>
                    <li><a href="#">Home</a></li>
                    <li><a href="#destinazioni">Destinazioni</a></li>
                    <li><a href="accedi.php" class="signup-btn">Accedi o Registrati</a></li>
                </ul>
            </nav>
        </header>
        
        <section class="hero">
            <div class="left-container">
                <div class="left-content">
                    <h4>Le miglior destinazioni al mondo</h4>
                    <h1>Viaggi, divertimento e tanto altro</h1>
                    <p>
                        Tour organizzati per un'esperienza unica, accedi per prenotare la tua!
                    </p>
                    <button class="contatti-btn"><a href="#contattaci">Contattaci</a></button>
                    <button class="prenotazioni-btn"><a href="https://it-it.facebook.com/">Social</a></button>
                </div>
            </div>
            <div class="right-container">
                <img src="../immagini/sfondo.png" alt="" width="580px">
            </div>
        </section>
        
        <section class="title-style" style="margin-bottom: 50px;">
            <div class="category-title">
                <h5 id="destinazioni">Tutto l'anno</h5>
                <h3>Le capitali europee piu' belle da visitare</h3>
            </div>
            <div class="services-card">
                <div class="destination-card">
                    <img src="../immagini/londra.jpg" alt="" width="75">
                    <h4>Londra, Inghilterra</h4>
                </div>
               
                <div class="destination-card">
                    <img src="../immagini/parigi.jpg" alt="" width="75">
                    <h4>Parigi, Francia</h4>
                </div>

                <div class="destination-card">
                    <img src="../immagini/berlino.jpg" alt="" width="75">
                    <h4>Berlino, Germania</h4>
                </div>

                <div class="destination-card">
                    <img src="../immagini/roma.jpg" alt="" width="75">
                    <h4>Roma, Italia</h4> 
                </div>
            </div>
        </section>

        <section class="title-style" style="margin-bottom: 50px;">
            <div class="category-title">
                <h5>Tutto l'anno</h5>
                <h3>Le spiagge europee piu' belle da vedere</h3>
            </div>
            <div class="services-card">
                <div class="destination-card">
                    <img src="../immagini/alanya.jpg" alt="" width="75">
                    <h4>Alanya, Turchia</h4>
                </div>

                <div class="destination-card">
                    <img src="../immagini/bonifacio.jpg" alt="" width="75">
                    <h4>Bonifacio, Francia</h4>
                </div>

                <div class="destination-card">
                    <img src="../immagini/rodas.jpg" alt="" width="75">
                    <h4>Rodas, Spagna</h4>
                </div>

                <div class="destination-card">
                    <img src="../immagini/reynisfjara.jpg" alt="" width="75">
                    <h4>Reynisfjara, Islanda</h4>
                </div>
            </div>
        </section>

        <section class="title-style" style="margin-bottom: 50px;">
            <div class="category-title">
                <h5>Tutto l'anno</h5>
                <h3>Le vette europee piu' belle da vedere</h3>
            </div>
            <div class="services-card">
                <div class="destination-card">
                    <img src="../immagini/dolomiti.jpg" alt="" width="75">
                    <h4>Dolomiti, Italia</h4>
                </div>

                <div class="destination-card">
                    <img src="../immagini/altitauri.jpg" alt="" width="75">
                    <h4>Alti Tauri, Austria</h4>
                </div>

                <div class="destination-card">
                    <img src="../immagini/pirenei.jpg" alt="" width="75">
                    <h4>Pirenei, Spagna</h4>
                </div>

                <div class="destination-card">
                    <img src="../immagini/stortoppen.jpg" alt="" width="75">
                    <h4>Stortoppen, Svezia</h4>
                </div>
            </div>
        </section>
        
        <div class="container">
            <h1 id="contattaci">Contattaci!</h1>
            <p>Non esitare a contattarci per qualsiasi informazione. Ti risponderemo il prima possibile.</p>
        
            <?php
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $nome = $_POST["nome"];
            $email = $_POST["email"];
            $messaggio = $_POST["messaggio"];
                echo "<p>Messaggio inviato con successo!</p>";
            } else {
                echo "";
            }
            ?>

            <form method="POST" action="index.php#contattaci">

                <label for="nome">Nome:</label>
                <input type="text" name="nome" id="nome" required>
        
                <label for="email">Email:</label>
                <input type="email" name="email" id="email" required>
        
                <label for="messaggio">Messaggio:</label>
                <textarea name="messaggio" id="messaggio" rows="5" required></textarea>
        
                <div class="invia"><input type="submit" value="Invia"></div>
                
            </form>
        </div>
    </body>
</html>
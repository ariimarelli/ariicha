<?php
session_start();

if (isset($_SESSION['id']) && isset($_SESSION['nome_utente'])) {

?>

<!DOCTYPE html>
<html>
    <head>
	    <title>Ariicha Agency | Prenota</title>
	    <link rel="stylesheet" type="text/css" href="../css/styles.css">
    </head>
    <body>
        <header>
            <img src="../immagini/logo.jpg" alt="" width="250px">
            <nav class="navbar">
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="index.php#destinazioni">Destinazioni</a></li>
                </ul>
            </nav>
        </header>
    
        <div class="elenco">
            <br></br>
            <h1>Ciao, <?php echo $_SESSION['nome']; ?></h1>
        
            <form>
                <button type="submit"><a href="prenotazionec.php">Prenota </a></button>
                <br></br>
                <br></br>
                <a>OPPURE</a>
                <br></br>
                <br></br>
                <button type="submit"><a href="disconnettiti.php">Disconnettiti</a></button>
            </form>

        </div>
    </body>
</html>

<?php 
}else{
    header("Location: accedi.php");
    exit();
}
?>
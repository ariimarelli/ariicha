<?php

$snome= "localhost";
$nome_ut= "root";
$password = "";

$db_nome = "test_db";

$conn = mysqli_connect($snome, $nome_ut, $password, $db_nome);

if (!$conn) {
	echo "Connessione fallita!";
}